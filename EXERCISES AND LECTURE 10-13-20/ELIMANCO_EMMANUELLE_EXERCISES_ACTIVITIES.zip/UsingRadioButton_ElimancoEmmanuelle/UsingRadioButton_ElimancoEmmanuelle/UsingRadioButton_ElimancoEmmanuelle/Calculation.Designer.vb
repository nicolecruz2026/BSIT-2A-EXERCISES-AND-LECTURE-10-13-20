﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Calculation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.txtNumber2 = New System.Windows.Forms.TextBox()
        Me.txtNumber1 = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.rdoDivision = New System.Windows.Forms.RadioButton()
        Me.rdoMultiplication = New System.Windows.Forms.RadioButton()
        Me.rdoSubstraction = New System.Windows.Forms.RadioButton()
        Me.rdoAddition = New System.Windows.Forms.RadioButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.txtResult)
        Me.Panel1.Controls.Add(Me.txtNumber2)
        Me.Panel1.Controls.Add(Me.txtNumber1)
        Me.Panel1.Location = New System.Drawing.Point(14, 19)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(260, 160)
        Me.Panel1.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 118)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Result :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Number &2 :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Number &1 :"
        '
        'txtResult
        '
        Me.txtResult.Enabled = False
        Me.txtResult.Location = New System.Drawing.Point(126, 113)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(121, 22)
        Me.txtResult.TabIndex = 2
        Me.txtResult.Text = "0.00"
        Me.txtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtNumber2
        '
        Me.txtNumber2.Location = New System.Drawing.Point(126, 70)
        Me.txtNumber2.Name = "txtNumber2"
        Me.txtNumber2.Size = New System.Drawing.Size(121, 22)
        Me.txtNumber2.TabIndex = 1
        Me.txtNumber2.Text = "0.00"
        Me.txtNumber2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtNumber1
        '
        Me.txtNumber1.Location = New System.Drawing.Point(126, 26)
        Me.txtNumber1.Name = "txtNumber1"
        Me.txtNumber1.Size = New System.Drawing.Size(121, 22)
        Me.txtNumber1.TabIndex = 0
        Me.txtNumber1.Text = "0.00"
        Me.txtNumber1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.rdoDivision)
        Me.Panel2.Controls.Add(Me.rdoMultiplication)
        Me.Panel2.Controls.Add(Me.rdoSubstraction)
        Me.Panel2.Controls.Add(Me.rdoAddition)
        Me.Panel2.Location = New System.Drawing.Point(285, 18)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(178, 160)
        Me.Panel2.TabIndex = 1
        '
        'rdoDivision
        '
        Me.rdoDivision.AutoSize = True
        Me.rdoDivision.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoDivision.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.rdoDivision.Location = New System.Drawing.Point(30, 111)
        Me.rdoDivision.Name = "rdoDivision"
        Me.rdoDivision.Size = New System.Drawing.Size(121, 22)
        Me.rdoDivision.TabIndex = 3
        Me.rdoDivision.TabStop = True
        Me.rdoDivision.Text = "&Division          "
        Me.rdoDivision.UseVisualStyleBackColor = True
        '
        'rdoMultiplication
        '
        Me.rdoMultiplication.AutoSize = True
        Me.rdoMultiplication.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoMultiplication.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.rdoMultiplication.Location = New System.Drawing.Point(30, 83)
        Me.rdoMultiplication.Name = "rdoMultiplication"
        Me.rdoMultiplication.Size = New System.Drawing.Size(121, 22)
        Me.rdoMultiplication.TabIndex = 2
        Me.rdoMultiplication.TabStop = True
        Me.rdoMultiplication.Text = "&Multiplication  "
        Me.rdoMultiplication.UseVisualStyleBackColor = True
        '
        'rdoSubstraction
        '
        Me.rdoSubstraction.AutoSize = True
        Me.rdoSubstraction.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoSubstraction.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.rdoSubstraction.Location = New System.Drawing.Point(28, 55)
        Me.rdoSubstraction.Name = "rdoSubstraction"
        Me.rdoSubstraction.Size = New System.Drawing.Size(123, 22)
        Me.rdoSubstraction.TabIndex = 1
        Me.rdoSubstraction.TabStop = True
        Me.rdoSubstraction.Text = "&Substraction   "
        Me.rdoSubstraction.UseVisualStyleBackColor = True
        '
        'rdoAddition
        '
        Me.rdoAddition.AutoSize = True
        Me.rdoAddition.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoAddition.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.rdoAddition.Location = New System.Drawing.Point(28, 27)
        Me.rdoAddition.Name = "rdoAddition"
        Me.rdoAddition.Size = New System.Drawing.Size(123, 22)
        Me.rdoAddition.TabIndex = 0
        Me.rdoAddition.TabStop = True
        Me.rdoAddition.Text = "&Addition          "
        Me.rdoAddition.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Info
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Button1.Location = New System.Drawing.Point(12, 196)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(450, 42)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "&Close"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Calculation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Info
        Me.ClientSize = New System.Drawing.Size(481, 276)
        Me.ControlBox = False
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Calculation"
        Me.Text = "Calculation With Radio Buttons"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtResult As System.Windows.Forms.TextBox
    Friend WithEvents txtNumber2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNumber1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents rdoDivision As System.Windows.Forms.RadioButton
    Friend WithEvents rdoMultiplication As System.Windows.Forms.RadioButton
    Friend WithEvents rdoSubstraction As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAddition As System.Windows.Forms.RadioButton
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
