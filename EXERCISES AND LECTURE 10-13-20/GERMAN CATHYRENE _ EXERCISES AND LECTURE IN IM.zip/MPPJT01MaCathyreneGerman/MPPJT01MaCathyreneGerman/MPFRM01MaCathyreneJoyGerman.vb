﻿Public Class MPFRM01MaCathyreneJoyGerman

    Dim result, arg1, arg2 As Integer

    Private Sub MPFRM01MaCathyreneGerman_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        arg1 = Val(TextBox1.Text)
        arg2 = Val(TextBox2.Text)

        result = arg1 + arg2

        TextBox3.Text = result

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        arg1 = Val(TextBox1.Text)
        arg2 = Val(TextBox2.Text)

        result = arg1 - arg2

        TextBox3.Text = result
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        arg1 = Val(TextBox1.Text)
        arg2 = Val(TextBox2.Text)

        result = arg1 * arg2

        TextBox3.Text = result
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        arg1 = Val(TextBox1.Text)
        arg2 = Val(TextBox2.Text)

        result = arg1 / arg2

        TextBox3.Text = result
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        arg1 = Val(TextBox1.Text)
        arg2 = Val(TextBox2.Text)

        result = arg1 Mod arg2

        TextBox3.Text = result
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        arg1 = Val(TextBox1.Text)
        arg2 = Val(TextBox2.Text)

        result = arg1 \ arg2

        TextBox3.Text = result
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub
End Class
