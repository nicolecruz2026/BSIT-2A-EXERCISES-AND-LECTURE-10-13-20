﻿Public Class Studentinfo

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ListBox1.Items.Add(TextBox1.Text & vbTab & vbTab + TextBox2.Text & vbTab & vbTab + TextBox3.Text & vbTab & vbTab + TextBox4.Text)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ListBox1.Items.Remove(TextBox1.Text & vbTab & vbTab + TextBox2.Text & vbTab & vbTab + TextBox3.Text & vbTab & vbTab + TextBox4.Text)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Close()

    End Sub
End Class
