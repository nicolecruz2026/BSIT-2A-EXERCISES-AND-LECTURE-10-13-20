﻿Public Class Exer3

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username As String = "Admin"
        Dim password As String = "Administration"

        If username = TextBox1.Text And password = TextBox2.Text Then
            MessageBox.Show("Log in Succesful")
        Else
            MessageBox.Show("Wrong Password")

        End If

    End Sub
End Class