﻿Public Class ColorChanger

    Private Sub ColorChanger_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        pnlPreview.BackColor = System.Drawing.Color.FromArgb(128, 128, 128)
    End Sub

    Private Sub scrRed_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles scrRed.Scroll
        Dim RedValue As Integer
        Dim GreenValue As Integer
        Dim BlueValue As Integer
        RedValue = scrRed.Value
        GreenValue = scrGreen.Value
        BlueValue = scrBlue.Value

        pnlPreview.BackColor = System.Drawing.Color.FromArgb(RedValue, GreenValue,
        BlueValue)
    End Sub

    Private Sub scrGreen_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles scrGreen.Scroll
        Dim RedValue As Integer
        Dim GreenValue As Integer
        Dim BlueValue As Integer
        RedValue = scrRed.Value
        GreenValue = scrGreen.Value
        BlueValue = scrBlue.Value

        pnlPreview.BackColor = System.Drawing.Color.FromArgb(RedValue, GreenValue,
        BlueValue)

    End Sub


    Private Sub scrBlue_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles scrBlue.Scroll
        Dim RedValue As Integer
        Dim GreenValue As Integer
        Dim BlueValue As Integer
        RedValue = scrRed.Value
        GreenValue = scrGreen.Value
        BlueValue = scrBlue.Value

        pnlPreview.BackColor = System.Drawing.Color.FromArgb(RedValue, GreenValue,
        BlueValue)
    End Sub
End Class