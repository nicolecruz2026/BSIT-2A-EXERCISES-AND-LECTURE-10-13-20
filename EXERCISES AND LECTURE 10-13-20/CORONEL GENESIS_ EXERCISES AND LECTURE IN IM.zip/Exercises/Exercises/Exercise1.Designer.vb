﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Exercise1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Colorbox = New System.Windows.Forms.TextBox()
        Me.Clickmebttn = New System.Windows.Forms.Button()
        Me.Clearbttn = New System.Windows.Forms.Button()
        Me.Closebttn = New System.Windows.Forms.Button()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter a Letter"
        '
        'Colorbox
        '
        Me.Colorbox.Location = New System.Drawing.Point(226, 32)
        Me.Colorbox.Multiline = True
        Me.Colorbox.Name = "Colorbox"
        Me.Colorbox.Size = New System.Drawing.Size(114, 28)
        Me.Colorbox.TabIndex = 1
        Me.Colorbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Clickmebttn
        '
        Me.Clickmebttn.Location = New System.Drawing.Point(28, 147)
        Me.Clickmebttn.Name = "Clickmebttn"
        Me.Clickmebttn.Size = New System.Drawing.Size(76, 34)
        Me.Clickmebttn.TabIndex = 2
        Me.Clickmebttn.Text = "Click Me!"
        Me.Clickmebttn.UseVisualStyleBackColor = True
        '
        'Clearbttn
        '
        Me.Clearbttn.Location = New System.Drawing.Point(147, 147)
        Me.Clearbttn.Name = "Clearbttn"
        Me.Clearbttn.Size = New System.Drawing.Size(76, 34)
        Me.Clearbttn.TabIndex = 3
        Me.Clearbttn.Text = "Clear"
        Me.Clearbttn.UseVisualStyleBackColor = True
        '
        'Closebttn
        '
        Me.Closebttn.Location = New System.Drawing.Point(264, 147)
        Me.Closebttn.Name = "Closebttn"
        Me.Closebttn.Size = New System.Drawing.Size(76, 34)
        Me.Closebttn.TabIndex = 3
        Me.Closebttn.Text = "Close"
        Me.Closebttn.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(82, 82)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(0, 32)
        Me.Label12.TabIndex = 4
        '
        'Exercise1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(372, 212)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Closebttn)
        Me.Controls.Add(Me.Clearbttn)
        Me.Controls.Add(Me.Clickmebttn)
        Me.Controls.Add(Me.Colorbox)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Exercise1"
        Me.Text = "Color Select"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Colorbox As System.Windows.Forms.TextBox
    Friend WithEvents Clickmebttn As System.Windows.Forms.Button
    Friend WithEvents Clearbttn As System.Windows.Forms.Button
    Friend WithEvents Closebttn As System.Windows.Forms.Button
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents Label12 As System.Windows.Forms.Label

End Class
