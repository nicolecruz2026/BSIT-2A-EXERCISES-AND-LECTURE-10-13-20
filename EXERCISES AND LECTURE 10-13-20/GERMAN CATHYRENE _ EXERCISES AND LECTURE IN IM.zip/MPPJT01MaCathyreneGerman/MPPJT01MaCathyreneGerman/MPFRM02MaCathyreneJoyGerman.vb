﻿Public Class MPFRM02MaCathyreneJoyGerman

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim pre, mid, fin, result As Decimal
        pre = Val(TextBox1.Text)
        mid = Val(TextBox2.Text)
        fin = Val(TextBox3.Text)

        result = ((pre * 0.25) + (mid * 0.25) + (fin * 0.5))
        result = Format(result, "0.00")

        TextBox4.Text = result
    End Sub
End Class