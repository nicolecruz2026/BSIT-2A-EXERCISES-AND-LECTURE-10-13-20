﻿Public Class ListOfCars
    Public Make As String
    Public Model As String
    Public CarYear As Int16
    Public Doors As Byte
    Public CarPicture As String
End Class
