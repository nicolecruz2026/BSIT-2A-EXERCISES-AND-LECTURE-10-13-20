﻿Public Class SampleLogIn

    Private Sub btnClick_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClick.Click
        Dim username As String = "Admin"
        Dim password As String = "Administrator"
        If username = TextBox1.Text And password = TextBox2.Text Then
            MessageBox.Show("Login Successful")
        Else
            MessageBox.Show("Incorrect Username and Password")
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        End
    End Sub
End Class