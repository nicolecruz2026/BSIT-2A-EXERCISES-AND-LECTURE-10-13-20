﻿Public Class ColorSelect

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim choice As Char

        choice = UCase(TextBox1.Text)

        Select Case choice

            Case "R"
                Label1.Text = "Red"

            Case "G"
                Label1.Text = "Greeh"

            Case "B"
                Label1.Text = "Blue"

            Case "Y"
                Label1.Text = "Yellow"

            Case Else
                Label1.Text = "Unknown"
        End Select


        choice = LCase(TextBox1.Text)

        Select Case choice

            Case "r"
                Label1.Text = "Red"

            Case "g"
                Label1.Text = "Greeh"

            Case "b"
                Label1.Text = "Blue"

            Case "y"
                Label1.Text = "Yellow"

            Case Else
                Label1.Text = "Unknown"
        End Select
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
    End Sub


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class
