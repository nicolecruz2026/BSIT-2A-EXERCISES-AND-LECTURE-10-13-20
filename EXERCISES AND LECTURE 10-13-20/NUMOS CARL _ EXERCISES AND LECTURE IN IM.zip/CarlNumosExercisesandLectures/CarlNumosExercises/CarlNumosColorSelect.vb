﻿Public Class CarlNumosColorSelect


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim choice As Char

        choice = UCase(TextBox1.Text)
        Select Case choice

            Case "R"
                Label2.Text = "Red"
                Label2.ForeColor = Color.Red
            Case "B"
                Label2.Text = "Blue"
                Label2.ForeColor = Color.Blue
            Case "Y"
                Label2.Text = "Yellow"
                Label2.ForeColor = Color.Yellow
            Case "G"
                Label2.Text = "Green"
                Label2.ForeColor = Color.Green
            Case Else
                Label2.Text = "INVALID KEY"
                Label2.ForeColor = Color.Black

        End Select
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        Label2.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class
