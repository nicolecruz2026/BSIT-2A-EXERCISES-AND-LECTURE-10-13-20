﻿Public Class Using_Decrement

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Num1 As Integer = 12
        Do Until Num1 = 0
            ListBox1.Text = ListBox1.Items.Add(Num1)
            Num1 -= 2
        Loop
    End Sub
End Class