﻿Public Class MPFRM01EmmanuelleElimanco


    Private Sub btnCompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompute.Click
        Dim dis As Decimal
        Dim sum As Integer
        Dim subtract As Integer

        Const tv21 As Integer = 10000
        Const tv14 As Integer = 7500
        Const tv12 As Integer = 5000
        Const ds5 As Decimal = 0.05
        Const ds10 As Decimal = 0.01
        Const ds15 As Decimal = 0.15

        If cb21.Checked = True Then
            sum = sum + tv21
        End If
        If cb14.Checked = True Then
            sum = sum + tv14
        End If
        If cb12.Checked = True Then
            sum = sum + tv12
        End If

        If rdb5.Checked = True Then
            dis = ds5
        ElseIf rdb10.Checked = True Then
            dis = ds10
        ElseIf rdb15.Checked = True Then
            dis = ds15
        End If

        txtSub.Text = Format(sum, "0,000.00")
        dis = sum * dis
        txtDiscount.Text = Format(dis, "#,###.00")
        subtract = sum - dis
        txtNetAmount.Text = Format(subtract, "#,###.00")
    End Sub

    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        txtDiscount.Text = ""
        txtNetAmount.Text = ""
        txtSub.Text = ""
        cb21.Checked = False
        cb14.Checked = False
        cb12.Checked = False
        rdb10.Checked = False
        rdb15.Checked = False
        rdb5.Checked = False
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        End
    End Sub
End Class