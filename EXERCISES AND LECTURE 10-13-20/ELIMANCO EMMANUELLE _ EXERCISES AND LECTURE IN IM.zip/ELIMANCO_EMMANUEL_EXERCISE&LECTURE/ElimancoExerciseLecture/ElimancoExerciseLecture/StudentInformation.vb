﻿Public Class StudentInformation


    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        lb1.Items.Add(txtSudent.Text & vbTab & vbTab + txtFirst.Text & vbTab & vbTab + txtMiddle.Text & vbTab & vbTab + txtLast.Text)
    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        lb1.Items.Remove(txtSudent.Text & vbTab & vbTab + txtFirst.Text & vbTab & vbTab + txtMiddle.Text & vbTab & vbTab + txtLast.Text)
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtFirst.Text = ""
        txtLast.Text = ""
        txtMiddle.Text = ""
        txtSudent.Text = ""
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        End
    End Sub
End Class