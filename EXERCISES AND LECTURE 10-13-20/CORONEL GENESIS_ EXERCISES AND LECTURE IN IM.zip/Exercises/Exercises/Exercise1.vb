﻿Public Class Exercise1

    Private Sub Closebttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Closebttn.Click
        Close()
    End Sub

    Private Sub Clearbttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Clearbttn.Click
        Colorbox.Text = ""
    End Sub

    Private Sub Clickmebttn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Clickmebttn.Click
        Dim choice As Char
        choice = LCase(Colorbox.Text)
        Select Case choice
            Case "r"
                Label12.Text = "Red"
            Case "b"
                Label12.Text = "Blue"
            Case "y"
                Label12.Text = "Yellow"
            Case "g"
                Label12.Text = "SENIOR"
            Case Else
                Label12.Text = "OUT OF RANGE"
        End Select
    End Sub

    Private Sub Exercise1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
