﻿Public Class MPFRM03MaCathyreneJoyGerman

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim product, qty, subTotal, discount, netAmount As Integer

        product = Val(TextBox1.Text)
        qty = Val(TextBox2.Text)

        subTotal = product * qty
        discount = subTotal * 0.2

        netAmount = subTotal - discount

        TextBox3.Text = subTotal
        TextBox4.Text = discount
        TextBox5.Text = netAmount

    End Sub
End Class