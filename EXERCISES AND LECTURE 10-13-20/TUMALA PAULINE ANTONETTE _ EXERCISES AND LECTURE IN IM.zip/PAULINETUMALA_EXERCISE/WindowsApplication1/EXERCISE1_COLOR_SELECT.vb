﻿Public Class Form1

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim choice As Char
        choice = LCase(TextBox1.Text)
        Select Case choice
            Case "r"
                Label2.Text = "Red"
            Case "b"
                Label2.Text = "Blue"
            Case "g"
                Label2.Text = "Green"
            Case Else
                Label2.Text = "Unknown"

        End Select
    End Sub
End Class
