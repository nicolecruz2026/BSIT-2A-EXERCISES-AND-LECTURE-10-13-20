﻿Public Class CarlNumosSampleLogin

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim username As String = "Admin"
        Dim password As String = "Administrator"
        If username = TextBox1.Text And password = TextBox2.Text Then
            MessageBox.Show("Login Successful")
        Else
            MessageBox.Show("Incorrect Username and Password")
        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class