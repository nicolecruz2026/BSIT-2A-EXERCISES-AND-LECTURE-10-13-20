﻿Public Class SamplePassword

    
    Private Sub btnClick_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClick.Click
        If txtEnter.Text = "Password" Then
            MessageBox.Show("Access Granted", "Password", MessageBoxButtons.OK,
            MessageBoxIcon.Information)
        Else
            MessageBox.Show("Access Denied", "Password", MessageBoxButtons.OK,
            MessageBoxIcon.Information)
        End If
    End Sub
   
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtEnter.Text = ""
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        End
    End Sub
End Class