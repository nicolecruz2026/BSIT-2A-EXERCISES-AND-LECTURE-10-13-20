﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ColorChanger
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlPreview = New System.Windows.Forms.Panel()
        Me.scrRed = New System.Windows.Forms.VScrollBar()
        Me.scrGreen = New System.Windows.Forms.VScrollBar()
        Me.scrBlue = New System.Windows.Forms.VScrollBar()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'pnlPreview
        '
        Me.pnlPreview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlPreview.Location = New System.Drawing.Point(13, 15)
        Me.pnlPreview.Name = "pnlPreview"
        Me.pnlPreview.Size = New System.Drawing.Size(243, 220)
        Me.pnlPreview.TabIndex = 0
        '
        'scrRed
        '
        Me.scrRed.Location = New System.Drawing.Point(281, 15)
        Me.scrRed.Maximum = 255
        Me.scrRed.Name = "scrRed"
        Me.scrRed.Size = New System.Drawing.Size(21, 220)
        Me.scrRed.TabIndex = 1
        Me.scrRed.Value = 128
        '
        'scrGreen
        '
        Me.scrGreen.Location = New System.Drawing.Point(316, 15)
        Me.scrGreen.Maximum = 255
        Me.scrGreen.Name = "scrGreen"
        Me.scrGreen.Size = New System.Drawing.Size(21, 220)
        Me.scrGreen.TabIndex = 2
        Me.scrGreen.Value = 128
        '
        'scrBlue
        '
        Me.scrBlue.Location = New System.Drawing.Point(351, 15)
        Me.scrBlue.Maximum = 255
        Me.scrBlue.Name = "scrBlue"
        Me.scrBlue.Size = New System.Drawing.Size(21, 220)
        Me.scrBlue.TabIndex = 3
        Me.scrBlue.Value = 128
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(86, 262)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(98, 34)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(278, 250)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(18, 17)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "R"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(313, 250)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "G"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(348, 250)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(17, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "B"
        '
        'ColorChanger
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(381, 334)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.scrBlue)
        Me.Controls.Add(Me.scrGreen)
        Me.Controls.Add(Me.scrRed)
        Me.Controls.Add(Me.pnlPreview)
        Me.Name = "ColorChanger"
        Me.Text = "ColorChanger"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlPreview As System.Windows.Forms.Panel
    Friend WithEvents scrRed As System.Windows.Forms.VScrollBar
    Friend WithEvents scrGreen As System.Windows.Forms.VScrollBar
    Friend WithEvents scrBlue As System.Windows.Forms.VScrollBar
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
