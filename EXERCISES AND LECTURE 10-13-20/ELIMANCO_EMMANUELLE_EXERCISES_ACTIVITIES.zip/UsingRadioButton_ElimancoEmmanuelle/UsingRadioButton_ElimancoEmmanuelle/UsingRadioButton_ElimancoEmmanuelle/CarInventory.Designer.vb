﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CarInventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtDoors = New System.Windows.Forms.TextBox()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.txtModel = New System.Windows.Forms.TextBox()
        Me.txtMake = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pctCarPicture = New System.Windows.Forms.PictureBox()
        Me.trbSlider = New System.Windows.Forms.TrackBar()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pctCarPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trbSlider, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtDoors)
        Me.GroupBox1.Controls.Add(Me.txtYear)
        Me.GroupBox1.Controls.Add(Me.txtModel)
        Me.GroupBox1.Controls.Add(Me.txtMake)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 18)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(223, 168)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Car Description :"
        '
        'txtDoors
        '
        Me.txtDoors.Location = New System.Drawing.Point(67, 120)
        Me.txtDoors.Name = "txtDoors"
        Me.txtDoors.Size = New System.Drawing.Size(130, 22)
        Me.txtDoors.TabIndex = 7
        Me.txtDoors.Text = "4"
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(66, 88)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(130, 22)
        Me.txtYear.TabIndex = 6
        Me.txtYear.Text = "1998"
        '
        'txtModel
        '
        Me.txtModel.Location = New System.Drawing.Point(67, 59)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(130, 22)
        Me.txtModel.TabIndex = 5
        Me.txtModel.Text = "Civic"
        '
        'txtMake
        '
        Me.txtMake.Location = New System.Drawing.Point(67, 28)
        Me.txtMake.Name = "txtMake"
        Me.txtMake.Size = New System.Drawing.Size(130, 22)
        Me.txtMake.TabIndex = 4
        Me.txtMake.Text = "Honda"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Doors:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Year :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Model :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Make :"
        '
        'pctCarPicture
        '
        Me.pctCarPicture.Image = Global.UsingRadioButton_ElimancoEmmanuelle.My.Resources.Resources.Civic1
        Me.pctCarPicture.Location = New System.Drawing.Point(249, 29)
        Me.pctCarPicture.Name = "pctCarPicture"
        Me.pctCarPicture.Size = New System.Drawing.Size(257, 157)
        Me.pctCarPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pctCarPicture.TabIndex = 1
        Me.pctCarPicture.TabStop = False
        '
        'trbSlider
        '
        Me.trbSlider.Location = New System.Drawing.Point(12, 209)
        Me.trbSlider.Minimum = 1
        Me.trbSlider.Name = "trbSlider"
        Me.trbSlider.Size = New System.Drawing.Size(224, 56)
        Me.trbSlider.TabIndex = 2
        Me.trbSlider.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.trbSlider.Value = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(249, 222)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(257, 31)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "&Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CarInventory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(518, 281)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.trbSlider)
        Me.Controls.Add(Me.pctCarPicture)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "CarInventory"
        Me.Text = "CarInventory"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.pctCarPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trbSlider, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtDoors As System.Windows.Forms.TextBox
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents txtModel As System.Windows.Forms.TextBox
    Friend WithEvents txtMake As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pctCarPicture As System.Windows.Forms.PictureBox
    Friend WithEvents trbSlider As System.Windows.Forms.TrackBar
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
