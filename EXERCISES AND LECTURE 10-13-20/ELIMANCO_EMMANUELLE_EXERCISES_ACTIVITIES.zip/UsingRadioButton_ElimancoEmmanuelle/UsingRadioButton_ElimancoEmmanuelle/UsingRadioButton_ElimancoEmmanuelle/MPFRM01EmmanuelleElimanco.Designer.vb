﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM01EmmanuelleElimanco
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cb12 = New System.Windows.Forms.CheckBox()
        Me.cb14 = New System.Windows.Forms.CheckBox()
        Me.cb21 = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rdb15 = New System.Windows.Forms.RadioButton()
        Me.rdb10 = New System.Windows.Forms.RadioButton()
        Me.rdb5 = New System.Windows.Forms.RadioButton()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblSub = New System.Windows.Forms.Label()
        Me.lblDiscount = New System.Windows.Forms.Label()
        Me.lblNetAmount = New System.Windows.Forms.Label()
        Me.txtSub = New System.Windows.Forms.TextBox()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.txtNetAmount = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cb12)
        Me.GroupBox1.Controls.Add(Me.cb14)
        Me.GroupBox1.Controls.Add(Me.cb21)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(18, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(263, 182)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Items here :"
        '
        'cb12
        '
        Me.cb12.AutoSize = True
        Me.cb12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb12.Location = New System.Drawing.Point(31, 141)
        Me.cb12.Name = "cb12"
        Me.cb12.Size = New System.Drawing.Size(143, 21)
        Me.cb12.TabIndex = 2
        Me.cb12.Text = "TV 12"" (5,000.00)"
        Me.cb12.UseVisualStyleBackColor = True
        '
        'cb14
        '
        Me.cb14.AutoSize = True
        Me.cb14.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb14.Location = New System.Drawing.Point(31, 94)
        Me.cb14.Name = "cb14"
        Me.cb14.Size = New System.Drawing.Size(151, 21)
        Me.cb14.TabIndex = 1
        Me.cb14.Text = "TV 14"" (74,500.00)"
        Me.cb14.UseVisualStyleBackColor = True
        '
        'cb21
        '
        Me.cb21.AutoSize = True
        Me.cb21.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb21.Location = New System.Drawing.Point(31, 47)
        Me.cb21.Name = "cb21"
        Me.cb21.Size = New System.Drawing.Size(151, 21)
        Me.cb21.TabIndex = 0
        Me.cb21.Text = "TV 21"" (10,000.00)"
        Me.cb21.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rdb15)
        Me.GroupBox2.Controls.Add(Me.rdb10)
        Me.GroupBox2.Controls.Add(Me.rdb5)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(301, 27)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(152, 181)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Discount"
        '
        'rdb15
        '
        Me.rdb15.AutoSize = True
        Me.rdb15.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb15.Location = New System.Drawing.Point(19, 141)
        Me.rdb15.Name = "rdb15"
        Me.rdb15.Size = New System.Drawing.Size(57, 21)
        Me.rdb15.TabIndex = 2
        Me.rdb15.TabStop = True
        Me.rdb15.Text = "15%"
        Me.rdb15.UseVisualStyleBackColor = True
        '
        'rdb10
        '
        Me.rdb10.AutoSize = True
        Me.rdb10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb10.Location = New System.Drawing.Point(19, 94)
        Me.rdb10.Name = "rdb10"
        Me.rdb10.Size = New System.Drawing.Size(57, 21)
        Me.rdb10.TabIndex = 1
        Me.rdb10.TabStop = True
        Me.rdb10.Text = "10%"
        Me.rdb10.UseVisualStyleBackColor = True
        '
        'rdb5
        '
        Me.rdb5.AutoSize = True
        Me.rdb5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb5.Location = New System.Drawing.Point(19, 47)
        Me.rdb5.Name = "rdb5"
        Me.rdb5.Size = New System.Drawing.Size(49, 21)
        Me.rdb5.TabIndex = 0
        Me.rdb5.TabStop = True
        Me.rdb5.Text = "5%"
        Me.rdb5.UseVisualStyleBackColor = True
        '
        'btnCompute
        '
        Me.btnCompute.Location = New System.Drawing.Point(23, 222)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(126, 36)
        Me.btnCompute.TabIndex = 2
        Me.btnCompute.Text = "&Compute"
        Me.btnCompute.UseVisualStyleBackColor = True
        '
        'btnClearAll
        '
        Me.btnClearAll.Location = New System.Drawing.Point(23, 264)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(126, 36)
        Me.btnClearAll.TabIndex = 3
        Me.btnClearAll.Text = "Clear &All"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(23, 306)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(126, 36)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "C&lose"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblSub
        '
        Me.lblSub.AutoSize = True
        Me.lblSub.Location = New System.Drawing.Point(169, 232)
        Me.lblSub.Name = "lblSub"
        Me.lblSub.Size = New System.Drawing.Size(70, 17)
        Me.lblSub.TabIndex = 5
        Me.lblSub.Text = "Sub-Total"
        '
        'lblDiscount
        '
        Me.lblDiscount.AutoSize = True
        Me.lblDiscount.Location = New System.Drawing.Point(169, 274)
        Me.lblDiscount.Name = "lblDiscount"
        Me.lblDiscount.Size = New System.Drawing.Size(63, 17)
        Me.lblDiscount.TabIndex = 6
        Me.lblDiscount.Text = "Discount"
        '
        'lblNetAmount
        '
        Me.lblNetAmount.AutoSize = True
        Me.lblNetAmount.Location = New System.Drawing.Point(169, 316)
        Me.lblNetAmount.Name = "lblNetAmount"
        Me.lblNetAmount.Size = New System.Drawing.Size(82, 17)
        Me.lblNetAmount.TabIndex = 7
        Me.lblNetAmount.Text = "Net Amount"
        '
        'txtSub
        '
        Me.txtSub.Enabled = False
        Me.txtSub.Location = New System.Drawing.Point(301, 229)
        Me.txtSub.Name = "txtSub"
        Me.txtSub.Size = New System.Drawing.Size(152, 22)
        Me.txtSub.TabIndex = 8
        '
        'txtDiscount
        '
        Me.txtDiscount.Enabled = False
        Me.txtDiscount.Location = New System.Drawing.Point(301, 271)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(152, 22)
        Me.txtDiscount.TabIndex = 9
        '
        'txtNetAmount
        '
        Me.txtNetAmount.Enabled = False
        Me.txtNetAmount.Location = New System.Drawing.Point(301, 313)
        Me.txtNetAmount.Name = "txtNetAmount"
        Me.txtNetAmount.Size = New System.Drawing.Size(152, 22)
        Me.txtNetAmount.TabIndex = 10
        '
        'MPFRM01EmmanuelleElimanco
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(468, 353)
        Me.Controls.Add(Me.txtNetAmount)
        Me.Controls.Add(Me.txtDiscount)
        Me.Controls.Add(Me.txtSub)
        Me.Controls.Add(Me.lblNetAmount)
        Me.Controls.Add(Me.lblDiscount)
        Me.Controls.Add(Me.lblSub)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.btnCompute)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "MPFRM01EmmanuelleElimanco"
        Me.Text = "MPFRM01EmmanuelleElimanco"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cb12 As System.Windows.Forms.CheckBox
    Friend WithEvents cb14 As System.Windows.Forms.CheckBox
    Friend WithEvents cb21 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdb15 As System.Windows.Forms.RadioButton
    Friend WithEvents rdb10 As System.Windows.Forms.RadioButton
    Friend WithEvents rdb5 As System.Windows.Forms.RadioButton
    Friend WithEvents btnCompute As System.Windows.Forms.Button
    Friend WithEvents btnClearAll As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblSub As System.Windows.Forms.Label
    Friend WithEvents lblDiscount As System.Windows.Forms.Label
    Friend WithEvents lblNetAmount As System.Windows.Forms.Label
    Friend WithEvents txtSub As System.Windows.Forms.TextBox
    Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
    Friend WithEvents txtNetAmount As System.Windows.Forms.TextBox
End Class
