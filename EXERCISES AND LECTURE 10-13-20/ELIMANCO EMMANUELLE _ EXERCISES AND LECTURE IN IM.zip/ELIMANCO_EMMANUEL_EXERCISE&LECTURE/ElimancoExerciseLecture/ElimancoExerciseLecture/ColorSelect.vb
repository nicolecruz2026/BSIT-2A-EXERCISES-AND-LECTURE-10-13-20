﻿Public Class ColorSelect

    Private Sub btnClick_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClick.Click
        Dim choice As Char

        choice = LCase(txtEnter.Text)
        Select Case choice
            Case "r"
                lbl2.Text = "Red"
            Case "b"
                lbl3.Text = "Blue"
            Case "y"
                lbl4.Text = "Yellow"
            Case "g"
                lbl5.Text = "SENIOR"
            Case Else
                lbl5.Text = "OUT OF RANGE"
        End Select
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtEnter.Text = ""
        lbl2.Text = ""
        lbl3.Text = ""
        lbl4.Text = ""
        lbl5.Text = ""

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        End
    End Sub
End Class

